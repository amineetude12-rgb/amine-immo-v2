"""Calculs de rentabilité : aucune hypothèse implicite de loyer."""
from __future__ import annotations


def _n(x, default=0.0) -> float:
    try:
        val = float(x)
        return val if val == val and abs(val) != float("inf") else default
    except (TypeError, ValueError):
        return default


def monthly_payment(principal: float, rate_pct: float, years: float) -> float:
    principal = max(0, principal)
    months = max(1, round(years * 12))
    r = max(0, rate_pct) / 1200
    return principal / months if r == 0 else principal * r / (1 - (1 + r) ** (-months))


def calc(v: dict) -> dict:
    price = max(0, _n(v.get("price")))
    rent = max(0, _n(v.get("rent_monthly")))
    apport = max(0, _n(v.get("down_payment"), 10000))
    notary = max(0, _n(v.get("notary_pct"), 8)) / 100
    fees = max(0, _n(v.get("bank_fees"), 2500))
    works = max(0, _n(v.get("works")))
    furniture = max(0, _n(v.get("furniture"), 3000))
    years = max(1, _n(v.get("years"), 25))
    rate = max(0, _n(v.get("interest_pct"), 3.4))
    insurance_pct = max(0, _n(v.get("insurance_pct"), .2))
    vac = min(1, max(0, _n(v.get("vacancy_pct"), 4) / 100))
    management = min(1, max(0, _n(v.get("management_pct")) / 100))
    maintenance = min(1, max(0, _n(v.get("maintenance_pct"), 5) / 100))
    fixed = sum(max(0, _n(v.get(k))) for k in
                ("copro_nonrecoverable", "property_tax", "pno", "accounting", "cfe", "other_charges"))
    total_cost = price * (1 + notary) + fees + works + furniture
    loan = max(0, total_cost - apport)
    pay_bank = monthly_payment(loan, rate, years)
    pay_ins = loan * insurance_pct / 1200
    debt = pay_bank + pay_ins

    def scenario(mrent: float, mrate: float, mvac: float) -> dict:
        collected = mrent * 12 * (1 - mvac)
        variable_cost = collected * (management + maintenance)
        op_cost = fixed + variable_cost
        noi = collected - op_cost
        md = monthly_payment(loan, mrate, years) + pay_ins
        return {"collected_annual": round(collected, 2), "operating_cost_annual": round(op_cost, 2),
                "noi_annual": round(noi, 2), "monthly_debt": round(md, 2),
                "cashflow_monthly": round(noi / 12 - md, 2)}

    base = scenario(rent, rate, vac)
    result = {
        "total_cost": round(total_cost, 2), "loan": round(loan, 2),
        "monthly_payment_excl_insurance": round(pay_bank, 2),
        "monthly_insurance": round(pay_ins, 2),
        "monthly_debt": round(debt, 2),
        "gross_yield_pct": round(rent * 1200 / total_cost, 2) if total_cost and rent else None,
        "net_yield_pct": round(base["noi_annual"] * 100 / total_cost, 2) if total_cost and rent else None,
        "cashflow_monthly": base["cashflow_monthly"] if rent else None,
        "effort_monthly": round(max(0, -base["cashflow_monthly"]), 2) if rent else None,
        "noi_annual": base["noi_annual"] if rent else None,
        "annual_op_cost": base["operating_cost_annual"],
        "rent_break_even": None,
        "max_buy_price": None,
        "scenarios": {},
        "loan_rate_pct": rate,
    }
    multiplier = 12 * (1 - vac) * (1 - management - maintenance)
    if multiplier > 0:
        result["rent_break_even"] = round((fixed + debt * 12) / multiplier, 2)
        if rent > 0:
            max_affordable_monthly_debt = (rent * multiplier - fixed) / 12
            if max_affordable_monthly_debt >= 0:
                # Montant empruntable maximum pour atteindre un cash-flow nul.
                per_euro = monthly_payment(1, rate, years) + insurance_pct / 1200
                max_loan = max_affordable_monthly_debt / per_euro if per_euro else 0
                result["max_buy_price"] = round(max(0, (max_loan + apport - fees - works - furniture) / (1 + notary)), 2)
    if rent > 0:
        result["scenarios"] = {
            "Loyer −10 %": scenario(.9 * rent, rate, vac),
            "Taux +1 point": scenario(rent, rate + 1, vac),
            "1 mois de vacance": scenario(rent, rate, max(vac, 1/12)),
        }
    return result
