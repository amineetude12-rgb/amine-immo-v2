# Publication de AMINE IMMO V2 sur Render

**Statut : prêt pour publication, pas encore publié.** Cette archive ne crée pas de compte ni de serveur à elle seule.

## Avant le lancement

- Le dépôt GitHub doit contenir **à sa racine** `render.yaml`, `Dockerfile`, `app.py`, `requirements.txt`, `extract.py`, `finance.py`, `static/`, etc. Éviter d’envoyer l’archive .zip comme simple fichier dans le dépôt : le contenu doit être décompressé.
- Les informations personnelles ne doivent pas être ajoutées au dépôt.
- Le fichier `render.yaml` sélectionne la région **Francfort**, le plan **Free**, et crée un code secret `APP_ACCESS_KEY` automatiquement.

## Mise en ligne

1. Importer le contenu du dossier `analyseur_immo_v2` dans un dépôt GitHub (privé de préférence).
2. Aller dans https://dashboard.render.com et connecter le dépôt GitHub à Render.
3. Choisir **New → Blueprint**, sélectionner le dépôt, puis valider la configuration `render.yaml`.
4. Attendre que le service passe à **Live** et relever l’adresse `https://...onrender.com` fournie par Render.
5. Tester `https://...onrender.com/health` : la réponse doit inclure `status: ok`, `ocr_available: true` si OCR installé.
6. Dans le tableau de bord Render, ouvrir l’environnement du service et retrouver le secret généré `APP_ACCESS_KEY` (ou le remplacer par un code fort de votre choix). Ne jamais publier cette clé.
7. Sur l’iPhone, ouvrir l’URL du site et lancer un premier calcul ou une première importation : saisir le code demandé **une seule fois sur cet appareil**. Le navigateur le conserve en local.
8. Depuis l’onglet **Safari** du site, copier le code du signet ou du raccourci, puis suivre `INSTALLATION_IPHONE.md`.

## Limites

- Le plan Free peut s’endormir en période d’inactivité. Le premier chargement est donc parfois lent.
- Le code d’accès protège les appels à l’API, mais n’est pas un système d’utilisateurs multiples.
- L’URL d’un site bloquant les robots peut nécessiter le signet Safari ou une capture.
- Pour la fiabilité, envisager à terme un plan payant et une isolation des sorties réseau. Les vérifications DNS de la version actuelle ne suffisent pas à exclure tous les risques de rebinding DNS sur une application Internet publique.
- Les estimations ne remplacent pas l’étude d’un financement, des charges réelles et de la fiscalité.

Documentation du fournisseur : https://render.com/docs/blueprints et https://render.com/docs/free
