# Installer « Analyser l'annonce » sur iPhone — Safari

## À faire une seule fois : publier l'application

Le fichier ZIP contient le site et son serveur d'importation. Une URL publique **HTTPS** est nécessaire pour l'utiliser depuis Safari sur iPhone. La version précédente en `chatgpt.site` n'est **pas** modifiée. Voir le `README.md` pour déployer cette nouvelle version sur un hébergement Python/Docker (Render, Railway, VPS, etc.).

Une fois le site publié, ouvre **sa nouvelle URL** dans Safari. Le bouton **Importer** fonctionne sur les annonces publiquement accessibles. Si un site refuse l'importation automatique, utilise la méthode suivante.

## Méthode recommandée : le raccourci Safari iPhone

1. Ouvre ton analyseur publié dans **Safari**.
2. Déplie **« Si le site bloque l'importation »**.
3. Touche **« Copier le script Raccourcis iPhone »**. Le code contient automatiquement la bonne URL de ton site.
4. Ouvre l'app **Raccourcis** sur l'iPhone, puis touche `+`.
5. Ajoute l'action **Exécuter JavaScript sur une page web** et colle le script.
6. Ajoute l'action **Ouvrir les URL** et indique comme entrée le résultat de l'action JavaScript précédente.
7. Renomme le raccourci **Analyser l'annonce**. Dans ses détails, active **Afficher dans la feuille de partage** et choisis l'entrée **Pages web Safari**.
8. Si iOS le demande, autorise **Exécuter des scripts** dans les réglages avancés de l'app Raccourcis. Autorise l'accès à la page lorsque cela est demandé.

**Utilisation :** sur une annonce ouverte dans Safari, touche **Partager → Analyser l'annonce**. Le raccourci lit **le contenu visible de l'annonce**, puis ouvre l'analyseur avec le texte récupéré. Tu n'as pas à sélectionner/coller manuellement le texte. Le site peut néanmoins empêcher l'accès au contenu même depuis la page ouverte.

## Alternative : un signet Safari « Analyser l'annonce »

1. Ouvre l'analyseur publié, déplie **« Si le site bloque l'importation »** et touche **« Copier le code du signet Safari »**.
2. Sur une page quelconque dans Safari, utilise **Partager → Ajouter un signet** (ou Ajouter aux favoris).
3. Donne-lui le nom **Analyser l'annonce** et enregistre-le.
4. Ouvre **Signets**, trouve ce signet, touche **Modifier** et **remplace toute l'adresse** par le code commençant par `javascript:` que tu as copié.
5. Enregistre. Depuis une annonce dans Safari, touche le signet pour lancer la capture et ouvrir l'analyseur.

> Sur certaines versions iOS ou certains sites, l'exécution des signets JavaScript est limitée. Le raccourci Safari est généralement plus pratique.

## Ajout sur l'écran d'accueil

Dans Safari, ouvre la nouvelle URL de l'analyseur, puis **Partager → Sur l'écran d'accueil → Ajouter**. C'est une icône qui ouvre l'analyseur ; **ce n'est pas** le raccourci de lecture des annonces.

## Limites importantes

- **Un lien seul** ne donne pas accès à une annonce si le site interdit les robots, exige une session, affiche un CAPTCHA ou cache des informations derrière un accès restreint.
- La lecture de la page ouverte utilise uniquement les données accessibles dans le navigateur où tu consultes l'annonce ; elle ne neutralise pas les sécurités du site.
- Le loyer reste à renseigner/valider. Prix, surface, taxe, charges, DPE et autres informations doivent être vérifiés.
- Les données de l'annonce capturées par le raccourci sont transmises à l'analyseur dans un fragment `#import=...` puis analysées par son serveur ; **ne copie pas ce lien de capture** dans une conversation publique.
