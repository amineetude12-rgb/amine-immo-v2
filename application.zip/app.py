"""API et application mobile de l'analyseur immobilier."""
import base64
import hmac
import io
import os
import shutil

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from extract import import_url, parse_text, parse_capture
from finance import calc

BASE=os.path.dirname(os.path.abspath(__file__))
app=FastAPI(title='Analyseur immobilier – Amine',version='2.1', docs_url=None, redoc_url=None, openapi_url=None)
app.mount('/static', StaticFiles(directory=os.path.join(BASE,'static')),name='static')

def require_access(request: Request):
    # En ligne, definir APP_ACCESS_KEY sur l'hebergeur. Le code n'est jamais livre dans le site.
    expected=os.environ.get('APP_ACCESS_KEY','')
    if expected and not hmac.compare_digest(request.headers.get('x-access-key',''), expected):
        raise HTTPException(status_code=401,detail="Code d'accès requis ou invalide.")


class ImportRequest(BaseModel):
    url:str=Field(max_length=2000)
class TextRequest(BaseModel):
    text:str=Field(max_length=80000)
    url:str=Field(default='',max_length=2000)
class CaptureRequest(BaseModel):
    url:str=Field(default="",max_length=2000)
    title:str=Field(default="",max_length=500)
    text:str=Field(default="",max_length=35000)
    ld:list=Field(default_factory=list,max_length=4)

class OcrRequest(BaseModel):
    images:list[str]=Field(min_length=1,max_length=6)
class CalcRequest(BaseModel):
    values:dict

@app.get('/')
def home():return FileResponse(os.path.join(BASE,'static','index.html'))

@app.get('/health')
def health():return {'status':'ok','version':'2.1','ocr_available':bool(shutil.which('tesseract'))}

@app.post('/api/import')
def api_import(req:ImportRequest, _: None = Depends(require_access)):
    try:return import_url(req.url.strip())
    except ValueError as e:raise HTTPException(400,str(e)) from e

@app.post('/api/text')
def api_text(req:TextRequest, _: None = Depends(require_access)):
    return parse_text(req.text,url=req.url,source='texte collé')

@app.post('/api/capture')
def api_capture(req:CaptureRequest, _: None = Depends(require_access)):
    return parse_capture(req.model_dump())

@app.post('/api/calc')
def api_calc(req:CalcRequest, _: None = Depends(require_access)):return calc(req.values)

@app.post('/api/ocr')
def api_ocr(req:OcrRequest, _: None = Depends(require_access)):
    if not shutil.which('tesseract'):
        raise HTTPException(503,'OCR non disponible sur cet hébergement ; utilise la lecture de texte de ton iPhone.')
    import pytesseract
    from PIL import Image, UnidentifiedImageError
    fragments=[]
    for entry in req.images:
        if not entry.startswith('data:image/') or ',' not in entry:
            raise HTTPException(400,'Format de capture non reconnu.')
        mime,encoded=entry.split(',',1)
        if not any(t in mime for t in ('jpeg','png','webp')):raise HTTPException(400,'Format de capture non autorisé.')
        if len(encoded)>5_500_000:raise HTTPException(413,'Image trop volumineuse (4 Mo maximum).')
        try:
            raw=base64.b64decode(encoded,validate=True)
            im=Image.open(io.BytesIO(raw));im.verify()
            im=Image.open(io.BytesIO(raw)).convert('RGB')
            if im.width*im.height>20_000_000:raise HTTPException(413,'Résolution excessive.')
            try: text=pytesseract.image_to_string(im,lang='fra+eng',config='--psm 3')
            except pytesseract.TesseractError:text=pytesseract.image_to_string(im,lang='eng',config='--psm 3')
            fragments.append(text)
        except (ValueError,UnidentifiedImageError,base64.binascii.Error, OSError) as e:
            raise HTTPException(400,'Capture endommagée ou non prise en charge.') from e
    parsed=parse_text('\n'.join(fragments),source='OCR captures')
    parsed['raw_text']='\n'.join(fragments)[:25000]
    return parsed
