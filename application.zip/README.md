# AMINE IMMO — Analyseur universel de rentabilité (V2)

**Application mobile et serveur Python prêts à déployer.** Le guide de publication le plus récent est `DEPLOIEMENT_RENDER.md`, qui intègre une clé d’accès sur les API de production. La version ne modifie pas la précédente application `chatgpt.site` : son accès d'administration n'est pas disponible ici.

## Fonctionnalités livrées

1. **Importer une annonce par URL** : récupération du HTML public, lecture des métadonnées/JSON-LD et extraction prudente des champs ; tentative avec **Jina Reader** si `USE_JINA=1` et si la lecture directe échoue.
2. **Secours Safari** : bouton générant un signet JavaScript ou un script « Exécuter JavaScript sur une page web » dans l'app Raccourcis. Il lit la page déjà ouverte et renvoie ses données à l'analyseur, sans copier-coller manuel du texte.
3. **Secours texte/captures** : extraction de la description collée ; jusqu'à 6 images OCR via Tesseract lorsque le serveur possède Tesseract. Le `Dockerfile` l'installe avec le français et l'anglais.
4. **Analyse financière** : prix total frais inclus, capital emprunté, mensualité et assurance, rentabilités brute/nette, cash-flow avant impôt, effort d'épargne, loyer d'équilibre, prix d'achat maximum à cash-flow nul, scénarios −10 % de loyer, +1 point de taux et un mois de vacance.
5. **Transparence** : preuve d'extraction par champ, loyer jamais simulé, taxe foncière/part non récupérable inconnues signalées, avertissements DPE et encadrement de loyers Est Ensemble.
6. **Sauvegarde locale** : historique sur l'appareil, export JSON, impression/PDF depuis le navigateur.

## Utilisation immédiate sur ordinateur

Depuis le dossier qui contient les fichiers :

```bash
python -m pip install -r requirements.txt
uvicorn app:app --host 127.0.0.1 --port 8000
```

Puis ouvrir **http://127.0.0.1:8000**. Pour activer la tentative de lecture externe, lancer :

```bash
USE_JINA=1 uvicorn app:app --host 127.0.0.1 --port 8000
```

Sous Windows PowerShell : `$env:USE_JINA="1"; uvicorn app:app --host 127.0.0.1 --port 8000`

**Version démo autonome** : le fichier `analyseur_immo_autonome.html` permet les calculs et sauvegardes sans serveur ; l'import automatique par URL, l'OCR et la lecture serveur ne sont pas fonctionnels lorsqu'il est ouvert comme fichier local.

## Publication en ligne pour l'iPhone (méthode simple)

**Solution A — hébergement Docker / Render :**

1. Décompresser ce ZIP et placer les fichiers dans un dépôt GitHub privé ou un dépôt de votre hébergeur.
2. Créer un *Web Service* depuis le dépôt, avec le `Dockerfile` fourni. Le fichier `render.yaml` constitue une configuration de départ et doit être ajusté selon l'offre de l'hébergeur.
3. Autoriser l'hébergeur à construire l'image et attendre la fourniture d'une URL publique HTTPS.
4. Ouvrir cette URL sur l'iPhone, puis suivre **INSTALLATION_IPHONE.md** pour créer le raccourci « Analyser l'annonce ».
5. Contrôler la disponibilité avec `https://VOTRE-DOMAINE/health` : `ocr_available` doit être `true` avec Docker.

**Solution B — VPS / ordinateur en réseau local :**

```bash
docker build -t amine-immo .
docker run -p 8000:8000 -e USE_JINA=1 amine-immo
```

Publier ensuite le service derrière un proxy HTTPS avant de l'utiliser sur iPhone en mobilité. **Ne pas publier un serveur de développement sans protection sur Internet.**

## Ce qui est automatique et ce qui ne peut pas l'être

| Source | Résultat attendu |
|---|---|
| Page HTML publique avec données structurées | Import automatisé souvent possible |
| Page publique plus complexe | Essai Jina Reader (requête depuis le serveur) |
| Anti-robot / CAPTCHA / connexion obligatoire | Import par URL susceptible d'échouer ; le raccourci Safari peut lire les données visibles dans une session ouverte |
| Copie du texte impossible | Raccourci Safari, puis capture + OCR si nécessaire |
| Loyer ou charges non indiqués | Saisie manuelle obligatoire pour une estimation fiable |

**Aucune garantie de compatibilité avec tous les sites** : le système n'essaye pas de casser les CAPTCHA, les authentifications ou les restrictions d'accès. Les règles des plateformes restent applicables.

## Formules

- `Coût total = prix × (1 + frais acquisition %) + travaux + meubles + frais bancaires`.
- `Emprunt = max(0, coût total − apport)`.
- `Mensualité = mensualité amortissable (taux nominal, durée) + capital initial × taux assurance annuel / 12`.
- `Loyers encaissés = loyer HC × 12 × (1 − vacance %)`. Les impayés sont inclus dans le même pourcentage.
- `Charges exploitation = taxe foncière + copro non récupérable + PNO + comptabilité + CFE + autres + loyers encaissés × (% gestion + % entretien)`.
- `NOI = loyers encaissés − charges exploitation`.
- `Rendement brut = loyer HC × 12 / coût total` ; `rendement net = NOI / coût total`, avant financement et fiscalité.
- `Cash-flow avant impôt = NOI / 12 − mensualité du crédit assurance comprise`.
- `Loyer d'équilibre` : loyer HC nécessaire pour que le cash-flow soit nul, toutes les hypothèses inchangées.
- `Prix maximal` : prix d'achat permettant un cash-flow nul dans le modèle, apport et frais constants ; ne correspond ni à une estimation de valeur de marché ni à une garantie de crédit bancaire.

**Attention :** cette version ne calcule **pas** l'impôt (micro-foncier, réel, LMNP, amortissements), la rentabilité à la revente, l'évolution des loyers ni les grosses rénovations futures non budgétées. Les valeurs indicatives de financement ne sont **pas des taux bancaires garantis**. Un loyer ne doit pas être validé sans étude du marché local et des plafonds éventuels.

## Données et sécurité

- L'app n'a pas de compte utilisateur ni de base de données. L'historique reste dans `localStorage` du navigateur.
- Pour importer une URL, le serveur contacte l'annonce ; si `USE_JINA=1`, il peut transmettre l'URL à **Jina Reader**, service tiers. Désactiver avec `USE_JINA=0` si souhaité.
- L'extraction Safari envoie le texte de la page visible à votre serveur pour traitement. Évite les pages contenant des données privées ou des pages de messagerie.
- L'API refuse les URL internes, les ports inhabituels, les IP privées, contrôle les redirections, limite les tailles et le temps des requêtes. Pour un service Internet ouvert, prévoir **une restriction réseau sortante contre les accès aux IP privées**, des limites de requêtes, des protections anti-abus, un nom de domaine et HTTPS ; un contrôle DNS seul n'est pas une protection SSRF complète.
- Déployer de préférence dans un environnement privé / accès limité, car l'endpoint d'importation pourrait être abusé sur un serveur public.

## Tests

```bash
python -m pytest -q
```

Les tests couvrent les calculs financiers, les extractions de texte/JSON-LD et certains liens interdits. Ils ne constituent pas une preuve de compatibilité avec toutes les annonces réelles ; chaque site est susceptible d'évoluer.

## Documentation réglementaire (consultée en novembre 2026)

- Service Public, DPE / location : https://www.service-public.fr/particuliers/actualites/A14608
- Service Public, encadrement Est Ensemble : https://www.service-public.fr/particuliers/vosdroits/F36219
- Apple, action JavaScript Safari/Raccourcis : https://support.apple.com/guide/shortcuts/use-the-run-javascript-on-webpage-action-apdb71a01d93/ios
- Jina Reader : https://docs.jina.ai/
