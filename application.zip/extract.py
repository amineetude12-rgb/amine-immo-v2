"""Récupération prudente de données publiques d'annonces, sans contournement de CAPTCHA.
Les champs ne sont renvoyés que si détectés, avec provenance traçable.
"""
from __future__ import annotations
import ipaddress
import json
import os
import re
import socket
from urllib.parse import urlsplit, urljoin

import requests
from bs4 import BeautifulSoup

FIELDS = ('title','price','surface','city','postal_code','rooms','dpe','copro_total','property_tax','rent_monthly','image')
MAX_HTML = 2_500_000
UA = 'Mozilla/5.0 (compatible; AnalyseurImmoPersonnel/2.0; +https://example.org)'
SPACE = r'\s\u00a0\u202f'
NUMBER = r'(\d[\d\s\u00a0\u202f.]{0,14}(?:,\d{1,2})?)'


def digits(value):
    if value is None: return None
    if isinstance(value, (int,float)): return float(value)
    s = re.sub(r'[^0-9,.]', '', str(value))
    if not s: return None
    if ',' in s: s=s.replace('.', '').replace(',', '.')
    elif s.count('.') > 1 or (s.count('.') == 1 and len(s.split('.')[-1]) == 3): s=s.replace('.', '')
    try: return float(s)
    except ValueError: return None


def valid_public_url(url, *, resolve_dns=True):
    """Réduit les risques SSRF; réseau privé interdit, y compris après redirection.
    Déployer le service dans un réseau à sorties contrôlées pour une défense complète.
    """
    if not isinstance(url,str) or len(url)>2000: raise ValueError('Lien invalide ou trop long.')
    p=urlsplit(url.strip())
    if p.scheme not in ('http','https') or not p.hostname or p.username or p.password:
        raise ValueError('Le lien doit commencer par https:// (ou http://).')
    host=p.hostname.strip('.').lower()
    if host in ('localhost',) or host.endswith(('.localhost','.local','.internal','.test')):
        raise ValueError('Adresse interne non autorisée.')
    if p.port not in (None,80,443): raise ValueError('Port non autorisé.')
    try:
        ip=ipaddress.ip_address(host)
        if not ip.is_global: raise ValueError('Adresse réseau privée non autorisée.')
    except ValueError as exc:
        if 'privée' in str(exc): raise
        if not re.fullmatch(r'[a-z0-9.-]+', host) or '.' not in host:
            raise ValueError('Nom de domaine invalide.')
    if resolve_dns:
        try: answers=socket.getaddrinfo(host, p.port or (443 if p.scheme=='https' else 80))
        except socket.gaierror: raise ValueError('Nom de domaine impossible à résoudre.')
        if not answers: raise ValueError('Aucune adresse réseau trouvée.')
        for row in answers:
            if not ipaddress.ip_address(row[4][0]).is_global:
                raise ValueError('Le lien redirige vers une adresse privée.')
    return url


def _collect_ld(obj, bag):
    if isinstance(obj, list):
        for x in obj: _collect_ld(x,bag)
    elif isinstance(obj,dict):
        bag.append(obj)
        if '@graph' in obj: _collect_ld(obj['@graph'],bag)
        if 'mainEntity' in obj: _collect_ld(obj['mainEntity'],bag)


def _ld_get(ld, *names):
    for obj in ld:
        for k in names:
            if obj.get(k) is not None and not isinstance(obj.get(k),(dict,list)):
                return obj[k]
    return None


def parse_text(text: str, *, url='', title='', hints=None, source='texte') -> dict:
    hints=hints or {}
    fields={}
    evidence={}
    def put(key, value, where, confidence='probable'):
        if value not in (None,'') and key not in fields:
            fields[key]=value
            evidence[key]={"source":where,"confidence":confidence}
    def find(pattern, flags=re.I):
        m=re.search(pattern,text,flags)
        return m.group(1) if m else None
    if title: put('title',title,source,'extrait')
    price_hint=digits(hints.get('price'))
    if price_hint and price_hint>=20000: put('price',round(price_hint),hints.get('price_source',source),'extrait')
    if hints.get('surface'):
        surf=digits(hints.get('surface'))
        if surf and 8<=surf<=10000: put('surface',surf,source,'extrait')
    for k in ('city','postal_code','rooms','dpe','image'):
        if hints.get(k): put(k,hints[k],source,'extrait')
    if 'price' not in fields:
        hit=find(r'\b(?:prix(?:\s+de\s+vente|\s+du\s+bien|\s+affich\w*)?|prix\s+de\s+vente)\s*[:\-]?\s*'+NUMBER+r'\s*(?:€|euros|eur)')
        if hit is None:
            # Certaines annonces placent le prix en titre sans libellé.
            hit=find(NUMBER+r'\s*(?:€|euros)\s*(?:\n|\||–|\-)?')
        amount=digits(hit)
        if amount and 20000<=amount<=10000000: put('price',round(amount),source)
    if 'surface' not in fields:
        hit=find(r'\bsurface\s*(?:habitable|totale|loi\s+carrez)?\s*[:\-]?\s*'+NUMBER+r'\s*m[²2]')
        if hit is None: hit=find(r'\b(\d{1,4}(?:[,.]\d{1,2})?)\s*m[²2]\b')
        amount=digits(hit)
        if amount and 8<=amount<=10000:put('surface',amount,source)
    if 'rooms' not in fields:
        hit=find(r'\b([1-9]\d?)\s*pi[eè]ces?\b')
        if hit: put('rooms',int(hit),source)
    if 'dpe' not in fields:
        hit=find(r'\b(?:DPE|classe\s+[ée]nerg[ée]tique|[ée]nergie)\s*[:\-]?\s*([A-G])\b')
        if hit: put('dpe',hit.upper(),source)
    if 'postal_code' not in fields:
        hit=find(r'\b((?:0[1-9]|[1-8]\d|9[0-8])\d{3})\b')
        if hit: put('postal_code',hit,source,'à confirmer')
    if 'city' not in fields:
        hit=find(r'\b(?:localisation|ville|commune)\s*[:\-]\s*([^\n,|;\d]{2,35})')
        if hit is None:
            # Ville immédiatement placée avant le code postal de l'annonce.
            m=re.search(r'\b([A-ZÀ-Ý][a-zà-ÿ\-]+(?:[ \-][A-Za-zÀ-ÿ]+){0,2})\s*\(\s*\d{5}\s*\)',title)
            if m:
                hit=re.sub(r'^(?:Appartement|Maison|Studio|Vente|Immeuble|Logement)\s+', '', m.group(1), flags=re.I)
        if hit: put('city',hit.strip(),source,'à confirmer')
    # Charges de copropriété affichées = charges TOTALES, non assimilées aux charges non récupérables.
    m=re.search(r'\bcharges?(?:\s+de\s+copropri[ée]t[ée])?(?:\s+annuelles?|\s+mensuelles?)?\s*[:\-]?\s*'+NUMBER+r'\s*(?:€|euros)\s*(?:/|par\s+)?\s*(mois|mensuel|trimestre|trimestriel|an|annuel|ann[ée]e)?',text,re.I)
    if m:
        val=digits(m.group(1)); period=(m.group(2) or '').lower()
        if val is not None and 1<=val<=60000:
            put('copro_total',round(val*(12 if period in ('mois','mensuel') else 4 if period in ('trimestre','trimestriel') else 1)),source,'à confirmer')
    m=re.search(r'\btaxe\s+fonci[eè]re\s*[:\-]?\s*'+NUMBER+r'\s*(?:€|euros)',text,re.I)
    if m:
        val=digits(m.group(1))
        if val and val<=30000: put('property_tax',round(val),source)
    m=re.search(r'\bloyer\s*(?:mensuel|hc|hors\s+charges|estim[ée])?\s*[:\-]?\s*'+NUMBER+r'\s*(?:€|euros)',text,re.I)
    if m:
        val=digits(m.group(1))
        if val and val<=50000:put('rent_monthly',round(val),source,'à confirmer')
    warnings=[]
    if 'price' not in fields: warnings.append('Prix non identifié : vérifie le montant sur l’annonce.')
    if 'surface' not in fields: warnings.append('Surface non identifiée.')
    if 'rent_monthly' not in fields: warnings.append('Loyer non trouvé : à renseigner manuellement (aucune estimation automatique).')
    if 'copro_total' in fields: warnings.append('Charges de copropriété annoncées : renseigne séparément la part NON récupérable.')
    if 'property_tax' not in fields: warnings.append('Taxe foncière inconnue : demande-la au vendeur.')
    return {"fields":fields,"evidence":evidence,"warnings":warnings,"source_url":url,"method":source}


def parse_html(content: str, *, url='') -> dict:
    soup=BeautifulSoup(content,'html.parser')
    ld=[]
    for s in soup.select('script[type="application/ld+json"]')[:20]:
        try:_collect_ld(json.loads(s.string or s.get_text()),ld)
        except (json.JSONDecodeError,TypeError,RecursionError): pass
    def meta(*keys):
        for k in keys:
            tag=soup.find('meta',attrs={'property':k}) or soup.find('meta',attrs={'name':k})
            if tag and tag.get('content'): return tag['content']
        return None
    product=[]
    for x in ld:
        ts=str(x.get('@type','')).lower()
        if any(z in ts for z in ('product','residence','apartment','house','realestate','offer')): product.append(x)
    if not product: product=ld
    hints={}
    for p in product:
        offer=p.get('offers')
        if isinstance(offer,list): offer=offer[0] if offer else None
        if isinstance(offer,dict) and not hints.get('price'):hints['price']=offer.get('price')
        if 'price' not in hints and p.get('price'):hints['price']=p['price']
        sz=p.get('floorSize') or p.get('size')
        if isinstance(sz,dict):sz=sz.get('value')
        if sz and not hints.get('surface'):hints['surface']=sz
        addr=p.get('address')
        if isinstance(addr,dict):
            if addr.get('addressLocality'):hints.setdefault('city',addr['addressLocality'])
            if addr.get('postalCode'):hints.setdefault('postal_code',str(addr['postalCode']))
        if p.get('image') and not hints.get('image'):
            im=p['image']
            if isinstance(im,list): im=im[0] if im else None
            if isinstance(im,dict):im=im.get('url')
            if isinstance(im,str):hints['image']=im
        if p.get('numberOfRooms'):hints.setdefault('rooms',p['numberOfRooms'])
    hints.setdefault('price',meta('product:price:amount','og:price:amount','price'))
    hints.setdefault('image',meta('og:image'))
    desc=meta('og:description','description') or ''
    title=meta('og:title') or (soup.title.get_text(' ',strip=True) if soup.title else '')
    for bad in soup(['script','style','nav','footer','header','noscript','form']):bad.decompose()
    text=soup.get_text('\n',strip=True)
    # Les pages contiennent souvent de multiples annonces : description et titre en tête.
    parsed=parse_text(title+'\n'+desc+'\n'+text[:35000],url=url,title=title,hints=hints,source='page et métadonnées')
    return parsed



def parse_capture(payload: dict) -> dict:
    """Traitement du contenu d'une annonce déjà ouverte dans Safari.
    On conserve les données structurées comme indice, sans faire confiance aux scripts.
    """
    ld=[]
    for item in (payload.get('ld') or [])[:4]:
        _collect_ld(item,ld)
    hints={}
    for entry in ld[:30]:
        offers=entry.get('offers')
        if isinstance(offers,list): offers=offers[0] if offers else None
        if isinstance(offers,dict) and offers.get('price'):
            hints.setdefault('price',offers['price'])
        if entry.get('price'): hints.setdefault('price',entry['price'])
        floor=entry.get('floorSize')
        if isinstance(floor,dict):floor=floor.get('value')
        if floor:hints.setdefault('surface',floor)
        address=entry.get('address')
        if isinstance(address,dict):
            if address.get('addressLocality'):hints.setdefault('city',address['addressLocality'])
            if address.get('postalCode'):hints.setdefault('postal_code',str(address['postalCode']))
        if entry.get('numberOfRooms'):hints.setdefault('rooms',entry['numberOfRooms'])
    text=str(payload.get('text') or '')[:30000]
    return parse_text(text,url=str(payload.get('url') or ''),title=str(payload.get('title') or '')[:300],
                      hints=hints,source='page ouverte dans Safari')

def _blocked(text):
    sample=text[:7000].lower()
    triggers=['captcha','verify you are human','vérifiez que vous êtes humain','access denied','attention required','just a moment...','robot or human','request blocked']
    return any(x in sample for x in triggers) and len(text)<18000


def fetch_direct(url):
    current=valid_public_url(url)
    for _ in range(5):
        with requests.get(current,headers={'User-Agent':UA,'Accept':'text/html,application/xhtml+xml'},timeout=(5,12),allow_redirects=False,stream=True) as r:
            if r.status_code in (301,302,303,307,308):
                location=r.headers.get('Location')
                if not location:raise RuntimeError('Redirection sans destination.')
                current=valid_public_url(urljoin(current,location));continue
            if r.status_code in (401,403,407,429,451):raise PermissionError(f'Le site refuse la lecture automatique (HTTP {r.status_code}).')
            r.raise_for_status()
            ct=r.headers.get('Content-Type','').lower()
            if ct and not any(k in ct for k in ('html','text/plain','xml')):
                raise ValueError('L’URL ne renvoie pas une page HTML.')
            chunks=[];size=0
            for c in r.iter_content(32768):
                size+=len(c)
                if size>MAX_HTML:raise ValueError('Page trop volumineuse.')
                chunks.append(c)
            body=b''.join(chunks).decode(r.encoding or 'utf-8','replace')
            if _blocked(body):raise PermissionError('Page de vérification humaine ou CAPTCHA.')
            return body,current
    raise RuntimeError('Trop de redirections.')


def fetch_jina(url):
    # Service tiers facultatif, sans contournement de contrôle d’accès.
    valid_public_url(url)
    if os.getenv('USE_JINA','0')!='1':
        raise PermissionError('Service de lecture externe non activé.')
    headers={'Accept':'application/json','X-Respond-With':'markdown'}
    if os.getenv('JINA_API_KEY'):headers['Authorization']='Bearer '+os.environ['JINA_API_KEY']
    resp=requests.get('https://r.jina.ai/'+url,headers=headers,timeout=(8,22))
    resp.raise_for_status()
    if len(resp.content)>MAX_HTML:raise ValueError('Réponse du service externe trop volumineuse.')
    try:
        data=resp.json()
        val=data.get('data',data)
        content=val.get('content','')
        title=val.get('title','')
    except (ValueError,AttributeError):content=resp.text;title=''
    if not content or _blocked(content):raise PermissionError('Page non accessible via le service externe.')
    return parse_text(content[:60000],url=url,title=title,source='lecture externe Jina Reader')


def import_url(url):
    valid_public_url(url)
    warnings=[]
    try:
        html,final_url=fetch_direct(url)
        result=parse_html(html,url=final_url)
        if result['fields'].get('price') and result['fields'].get('surface'):
            return result
        warnings.append('Lecture directe incomplète : tentative avec le lecteur alternatif.')
    except (requests.RequestException,PermissionError,ValueError,RuntimeError) as e:
        warnings.append(str(e))
    if os.getenv('USE_JINA','0')=='1':
        try:
            result=fetch_jina(url)
            result['warnings']=warnings+result['warnings']
            return result
        except (requests.RequestException,PermissionError,ValueError,RuntimeError) as e:
            warnings.append('Lecture externe indisponible : '+str(e))
    return {'fields':{},'evidence':{},'method':'bloqué','source_url':url,
            'blocked':True,'warnings':warnings+['Ouvre cette annonce dans Safari, utilise le raccourci « Analyser l’annonce » ou les captures d’écran.']}
