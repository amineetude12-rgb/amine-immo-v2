'use strict';
const $ = x => document.getElementById(x);
const VKEY='amine-immo-v2-draft', HKEY='amine-immo-v2-history';
const DEFAULTS={price:null,surface:null,city:'',postal_code:'',rooms:null,dpe:'',copro_total:null,property_tax:null,rent_monthly:null,down_payment:10000,notary_pct:8,works:0,furniture:3000,bank_fees:2500,years:25,interest_pct:3.4,insurance_pct:.2,copro_nonrecoverable:null,pno:120,accounting:0,cfe:0,other_charges:0,management_pct:0,maintenance_pct:5,vacancy_pct:4};
let values={...DEFAULTS}, evidence={}, lastWarnings=[], sourceUrl='', lastMethod='';
try { const saved=JSON.parse(localStorage.getItem(VKEY)||'null'); if(saved?.values){values={...DEFAULTS,...saved.values};evidence=saved.evidence||{};sourceUrl=saved.sourceUrl||'';}}catch(e){}
const property=[
  ['price','Prix affiché','€','number'],['surface','Surface','m²','number'],['city','Ville','','text'],['postal_code','Code postal','','text'],
  ['rooms','Nombre de pièces','','number'],['dpe','Classe DPE','','dpe'],['copro_total','Charges copro totales','€/an','number'],
  ['property_tax','Taxe foncière','€/an','number'],['rent_monthly','Loyer visé HC','€/mois','number']
];
const financing=[
  ['down_payment','Apport personnel','€','number'],['notary_pct','Frais acquisition','% du prix','number'],['works','Budget travaux','€','number'],
  ['furniture','Ameublement','€','number'],['bank_fees','Garantie + dossier','€','number'],['years','Durée du prêt','années','number'],
  ['interest_pct','Taux nominal','% / an','number'],['insurance_pct','Assurance emprunteur','% du capital initial / an','number']
];
const costs=[
  ['copro_nonrecoverable','Charges copro non récupérables','€/an','number'],['pno','Assurance PNO','€/an','number'],
  ['accounting','Comptabilité','€/an','number'],['cfe','CFE (si applicable)','€/an','number'],
  ['other_charges','Autres charges bailleur','€/an','number'],['vacancy_pct','Vacance / impayés','% des loyers','number'],
  ['management_pct','Gestion locative','% loyers encaissés','number'],['maintenance_pct','Entretien / réserve','% loyers encaissés','number']
];
const num=x=>{let n=typeof x==='string'?Number(x.replace(/\s/g,'').replace(',','.')):Number(x);return Number.isFinite(n)?n:0;};
const money=x=>x===null||x===undefined?'—':new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR',maximumFractionDigits:0}).format(x);
const decimalMoney=x=>x===null||x===undefined?'—':new Intl.NumberFormat('fr-FR',{style:'currency',currency:'EUR',maximumFractionDigits:2}).format(x);
const pct=x=>x===null||x===undefined?'—':new Intl.NumberFormat('fr-FR',{maximumFractionDigits:2}).format(x)+' %';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function makeField(spec){const [key,label,unit,type]=spec, wrapper=document.createElement('div'); wrapper.className='field';
 const status=evidence[key] ? (evidence[key].confidence==='à confirmer'?'À confirmer':'Extrait') : (values[key]===null||values[key]===''?'Inconnu':'Hypothèse');
 let control= type==='dpe' ? `<select id="fld-${key}" data-field="${key}"><option value="">Inconnu</option>${'ABCDEFG'.split('').map(x=>`<option value="${x}" ${values[key]===x?'selected':''}>${x}</option>`).join('')}</select>`
 : `<input id="fld-${key}" data-field="${key}" type="${type==='number'?'number':'text'}" ${type==='number'?'min="0" step="any" inputmode="decimal"':''} value="${esc(values[key]??'')}" placeholder="${type==='number'?'À renseigner':'—'}">`;
 wrapper.innerHTML=`<div class="field-label"><label for="fld-${key}">${label}</label><span class="provenance ${evidence[key]?'extracted':(status==='Hypothèse'?'assumed':'')}">${status}</span></div>${control}${unit?`<div class="unit">${unit}</div>`:''}`;
 wrapper.querySelector('[data-field]').addEventListener('input',e=>{
   let x=e.target.value; values[key]=type==='number'?(x===''?null:num(x)):x;
   delete evidence[key]; const span=wrapper.querySelector('.provenance');span.textContent=x===''?'Inconnu':'Saisi';span.className='provenance';
   persist();render();
 });return wrapper;}
function fields(){[['property-fields',property],['finance-fields',financing],['cost-fields',costs]].forEach(([id,arr])=>{$(id).replaceChildren(...arr.map(makeField));});}
function payment(loan,rate,years){if(loan<=0)return 0;const r=rate/1200,n=Math.max(1,Math.round(years*12));return !r?loan/n:loan*r/(1-Math.pow(1+r,-n));}
function calculate(v, rentFactor=1, rateExtra=0, vacancyOverride=null){
 const price=Math.max(0,num(v.price)), rent=Math.max(0,num(v.rent_monthly))*rentFactor;
 const notary=Math.max(0,num(v.notary_pct))/100;
 const total=price*(1+notary)+num(v.bank_fees)+num(v.works)+num(v.furniture);
 const loan=Math.max(0,total-num(v.down_payment));
 const r=Math.max(0,num(v.interest_pct)+rateExtra),years=Math.max(1,num(v.years));
 const insurance=loan*num(v.insurance_pct)/1200;
 const debt=payment(loan,r,years)+insurance;
 const vac=vacancyOverride===null?num(v.vacancy_pct)/100:vacancyOverride;
 const collected=rent*12*(1-Math.min(1,Math.max(0,vac)));
 const management=num(v.management_pct)/100,maintenance=num(v.maintenance_pct)/100;
 const fixed=['copro_nonrecoverable','property_tax','pno','accounting','cfe','other_charges'].reduce((s,k)=>s+Math.max(0,num(v[k])),0);
 const op= fixed + collected*(management+maintenance);
 const noi=collected-op, cf=noi/12-debt;
 const coeff=12*(1-vac)*(1-management-maintenance);
 const breakeven=coeff>0?(fixed+debt*12)/coeff:null;
 let maxPrice=null;
 if(coeff>0&&rent>0){const room=(rent*coeff-fixed)/12;if(room>=0){const perEuro=payment(1,r,years)+num(v.insurance_pct)/1200;const maxLoan=perEuro>0?room/perEuro:0;
 maxPrice=Math.max(0,(maxLoan+num(v.down_payment)-num(v.bank_fees)-num(v.works)-num(v.furniture))/(1+notary));}}
 return {price,rent,total,loan,insurance,debt,collected,op,noi,cf,
  gross:total&&rent?rent*1200/total:null,net:total&&rent?noi*100/total:null,breakeven,maxPrice};
}
function line(label,value){return `<div class="line"><span>${esc(label)}</span><b>${esc(value)}</b></div>`;}
function status(txt,isWarning=false){const e=$('import-status');e.hidden=false;e.className='callout'+(isWarning?' warning':'');e.textContent=txt;}
function render(){const c=calculate(values),ready=!!values.price&&!!values.rent_monthly;
 $('kpi-cash').textContent=ready?money(c.cf):'—';$('kpi-cash').className=ready?(c.cf>=0?'pos':'neg'):'';
 $('kpi-gross').textContent=ready?pct(c.gross):'—';$('kpi-net').textContent=ready?pct(c.net):'—';$('kpi-debt').textContent=values.price?money(c.debt):'—';
 $('results-sub').textContent=ready?'Estimation avant impôt sur le revenu, sur la base de tes hypothèses.':'Renseigne le prix et le loyer hors charges pour activer tous les indicateurs.';
 $('cash-info').textContent=ready?(c.cf<0?'Effort d’épargne '+money(-c.cf)+'/mois':'Excédent mensuel estimé'):'Après charges et remboursement';
 $('breakdown').innerHTML=line('Coût complet du projet',values.price?money(c.total):'—')+line('Apport',money(num(values.down_payment)))+line('Capital emprunté',values.price?money(c.loan):'—')+line('Mensualité hors assurance',values.price?money(c.debt-c.insurance):'—')+line('Assurance emprunteur / mois',values.price?decimalMoney(c.insurance):'—')+line('Revenus encaissés / an',values.rent_monthly?money(c.collected):'—')+line('Charges d’exploitation / an',money(c.op))+line('Résultat exploitation / an',ready?money(c.noi):'—');
 $('thresholds').innerHTML=line('Loyer d’équilibre HC / mois',values.price?money(c.breakeven):'—')+line('Prix d’achat maximal pour CF ≥ 0',ready?money(c.maxPrice):'—')+line('Effort d’épargne / mois',ready?money(Math.max(0,-c.cf)):'—')+line('Prix au m²',values.price&&values.surface?money(c.price/num(values.surface)):'—')+line('Rentabilité calculée sur','Coût total (frais inclus)');
 $('scenario-list').innerHTML=ready?[
  ['Situation actuelle',c.cf],['Loyer −10 %',calculate(values,.9).cf],['Taux du crédit +1 point',calculate(values,1,1).cf],['Vacance 1 mois minimum',calculate(values,1,0,Math.max(num(values.vacancy_pct)/100,1/12)).cf]
 ].map(([label,cf])=>`<div class="scenario-line"><span>${esc(label)}</span><b class="${cf>=0?'pos':'neg'}">${esc(money(cf))}</b></div>`).join(''):'<p class="support-hint">Les scénarios apparaîtront après saisie du loyer.</p>';
 const notices=[];const push=(text,kind='')=>notices.push(`<div class="notice ${kind}"><span class="notice-dot">${kind==='green'?'✓':'!'}</span><span>${esc(text)}</span></div>`);
 if(!values.price)push('Prix d’achat non renseigné : calcul financier incomplet.');
 if(!values.rent_monthly)push('Loyer HC manquant : aucun loyer fictif n’est inventé. Vérifie le loyer autorisé et de marché.');
 if(values.property_tax===null)push('Taxe foncière non confirmée : le calcul utilise provisoirement 0 €. Demander l’avis de taxe foncière.');
 if(values.copro_nonrecoverable===null)push('Part non récupérable des charges de copropriété non renseignée : résultat optimiste tant que cette donnée manque.');
 if(values.copro_total!==null)push('Charges totales annoncées '+money(num(values.copro_total))+'/an : ne pas déduire intégralement cette somme si une part est récupérable.');
 if(!values.dpe)push('DPE absent : demander le diagnostic complet et le programme de travaux.');
 if(values.dpe==='G')push('DPE G : en métropole, les logements G ne répondent plus au critère énergétique de décence pour les baux concernés depuis 2025. Vérifier travaux et exceptions.', 'red');
 if(values.dpe==='F')push('DPE F : échéance d’exclusion locative prévue en 2028 pour les baux concernés en métropole ; anticiper le coût des travaux.', 'red');
 if(values.dpe==='E')push('DPE E : anticiper l’échéance réglementaire prévue pour 2034 en métropole.');
 if(/montreuil|romainville|noisy.le.sec|les lilas|pantin|bagnolet|bondy|bobigny|pré.saint.gervais|pre.saint.gervais/i.test(String(values.city)))push('Territoire Est Ensemble : le loyer peut être encadré. Vérifier la référence applicable à la date du bail (meublé/vide, époque de construction, nombre de pièces).');
 if(num(values.price)>200000)push('Prix d’annonce supérieur à 200 000 € : dépasse le plafond de recherche initial du projet.');
 if(ready&&c.cf<-100)push('Cash-flow négatif supérieur à 100 €/mois dans les hypothèses actuelles : recalculer le prix d’achat et les charges.','red');
 if(ready&&c.cf>=0)push('Cash-flow estimé positif avant impôts, sous réserve de confirmer le loyer, les charges et les travaux.','green');
 lastWarnings.forEach(w=>push(w));
 $('alert-list').innerHTML=notices.join('');
}
function persist(){try{localStorage.setItem(VKEY,JSON.stringify({values,evidence,sourceUrl}));}catch(e){}}
function applyExtract(response){let found=0;const obj=response.fields||{};for(const [k,v] of Object.entries(obj)){
  if(!(k in DEFAULTS))continue;
  if(k==='rent_monthly'&&values.rent_monthly!==null){continue;} // Ne jamais écraser un loyer confirmé.
  values[k]=v;
  evidence[k]=response.evidence?.[k]||{source:response.method,confidence:'à confirmer'};
  found++;
 } sourceUrl=response.source_url||sourceUrl;lastMethod=response.method||'';lastWarnings=(response.warnings||[]).slice(0,8);
 fields();render();persist();status(found?`${found} donnée(s) récupérée(s) via ${lastMethod}. Vérifie et complète les champs signalés.`:'Aucune donnée fiable extraite. Ouvre l’annonce dans Safari et utilise le raccourci, ou colle son texte.',!found);
 $('property-panel').scrollIntoView({behavior:'smooth',block:'start'});
}
async function call(path,data){
  const payload=JSON.stringify(data);
  async function request(key){const headers={'Content-Type':'application/json'};if(key)headers['X-Access-Key']=key;return fetch(path,{method:'POST',headers,body:payload});}
  let key=localStorage.getItem('amine_immo_access_key')||'';
  let resp=await request(key);
  if(resp.status===401){
    key=window.prompt('Code d’accès de ton analyseur immobilier (dans les variables d’environnement Render) :')||'';
    if(!key)throw new Error('Code d’accès requis.');
    resp=await request(key);
    if(resp.ok)localStorage.setItem('amine_immo_access_key',key);
  }
  const res=await resp.json().catch(()=>({}));
  if(!resp.ok)throw new Error(typeof res.detail==='string'?res.detail:`Erreur ${resp.status}`);
  return res;
}
$('import-form').addEventListener('submit',async e=>{e.preventDefault();const url=$('ad-url').value.trim();if(!url)return;status('Lecture de l’annonce en cours…');$('import-btn').disabled=true;
 try{const result=await call('/api/import',{url});applyExtract(result);}
 catch(err){status('Import indisponible : '+err.message+'. Utilise le mode Safari ou colle le texte.',true);}finally{$('import-btn').disabled=false;}});
$('parse-text').addEventListener('click',async()=>{const text=$('pasted-text').value;if(!text.trim()){status('Colle le texte de l’annonce.',true);return;}try{applyExtract(await call('/api/text',{text,url:$('ad-url').value}));}catch(err){status(err.message,true);}});
$('parse-screenshots').addEventListener('click',async()=>{const files=Array.from($('screenshots').files||[]);if(!files.length||files.length>6){status('Sélectionne de 1 à 6 captures.',true);return;}
 try{const images=await Promise.all(files.map(file=>new Promise((resolve,reject)=>{if(file.size>4_000_000)return reject(Error('Capture de plus de 4 Mo.'));const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=()=>reject(Error('Lecture du fichier impossible.'));reader.readAsDataURL(file);})));status('Lecture OCR des captures…');const data=await call('/api/ocr',{images});if(data.raw_text)$('pasted-text').value=data.raw_text;applyExtract(data);}catch(err){status('OCR indisponible : '+err.message,true);}});
function capturePage(){const meta=(name)=>{const el=document.querySelector('meta[property="'+name+'"],meta[name="'+name+'"]');return el?el.content:'';};
 const jsonLd=[];for(const el of document.querySelectorAll('script[type="application/ld+json"]')){try{let x=JSON.parse(el.textContent);if(JSON.stringify(x).length<4000)jsonLd.push(x);}catch(e){}if(jsonLd.length>=3)break;}
 return {url:location.href,title:meta('og:title')||document.title,text:[meta('og:description'),meta('description'),(document.body&&document.body.innerText||'').slice(0,7500)].join('\n'),ld:jsonLd};}
function baseUrl(){return location.origin==='null'?'https://TON-SITE-ICI.example/':location.origin+'/';}
function bookmarklet(){const base=JSON.stringify(baseUrl());return 'javascript:(function(){try{var p=('+capturePage.toString()+')();location.href='+base+'+"#import="+encodeURIComponent(JSON.stringify(p));}catch(e){alert("Extraction impossible : "+e.message)}})();';}
function shortcutScript(){return '// Action Raccourcis : « Exécuter JavaScript sur une page web »\n// Puis action : « Ouvrir les URL » avec le résultat de cette action.\nvar capture=('+capturePage.toString()+')();\ncompletion('+JSON.stringify(baseUrl())+'+"#import="+encodeURIComponent(JSON.stringify(capture)));';}
async function copy(text){try{await navigator.clipboard.writeText(text);}catch(err){const a=document.createElement('textarea');a.value=text;document.body.appendChild(a);a.select();document.execCommand('copy');a.remove();}}
$('copy-bookmarklet').addEventListener('click',async()=>{if(location.protocol==='file:'||location.origin==='null'){status('Publie d’abord l’application sur une adresse HTTPS : le raccourci doit connaître son URL publique.',true);return;}await copy(bookmarklet());status('Code du signet copié. Dans Safari, crée un favori, modifie son adresse et colle ce code à la place.');});
$('copy-shortcut').addEventListener('click',async()=>{if(location.protocol==='file:'||location.origin==='null'){status('Publie d’abord l’application sur une adresse HTTPS : le raccourci doit connaître son URL publique.',true);return;}await copy(shortcutScript());status('Script copié. Dans Raccourcis, ajoute « Exécuter JavaScript sur une page web », colle le script, puis « Ouvrir les URL ». Active l’affichage dans la feuille de partage.');});
function getHistory(){try{return JSON.parse(localStorage.getItem(HKEY)||'[]');}catch(e){return [];}}
function drawHistory(){const h=getHistory();$('history').innerHTML=h.length?h.map((item,i)=>`<div class="history-row"><div><strong>${esc(item.name)}</strong><small>${esc(item.date)} · ${esc(money(item.values.price))} · ${esc(item.values.surface||'—')} m²</small></div><div><span class="cash">${esc(item.cash===null?'—':money(item.cash))}</span><button type="button" data-load="${i}">Ouvrir</button></div></div>`).join(''):'<p class="support-hint">Aucune analyse enregistrée sur cet appareil.</p>'; $('history').querySelectorAll('[data-load]').forEach(b=>b.addEventListener('click',()=>{const item=h[Number(b.dataset.load)];values={...DEFAULTS,...item.values};evidence=item.evidence||{};sourceUrl=item.sourceUrl||'';fields();render();persist();$('property-panel').scrollIntoView({behavior:'smooth'});}));}
$('save-analysis').addEventListener('click',()=>{const c=calculate(values);const h=getHistory();h.unshift({name:values.city||'Bien sans ville',date:new Date().toLocaleDateString('fr-FR'),values:{...values},evidence,sourceUrl,cash:values.price&&values.rent_monthly?c.cf:null});try{localStorage.setItem(HKEY,JSON.stringify(h.slice(0,25)));drawHistory();status('Analyse enregistrée dans ce navigateur.');window.scrollTo({top:0,behavior:'smooth'});}catch(e){status('Stockage local indisponible.',true);}});
$('clear-history').addEventListener('click',()=>{if(confirm('Effacer toutes les analyses sauvegardées sur cet appareil ?')){localStorage.removeItem(HKEY);drawHistory();}});
$('download-json').addEventListener('click',()=>{const payload={exportedAt:new Date().toISOString(),sourceUrl,values,evidence,calculation:calculate(values)};const b=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='analyse_immobiliere_'+new Date().toISOString().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);});
$('print-report').addEventListener('click',()=>window.print());
async function applyHash(){const hash=location.hash; if(!hash.startsWith('#import='))return;
 history.replaceState(null,'',location.pathname+location.search);try{const data=JSON.parse(decodeURIComponent(hash.slice(8)));if(data.url){$('ad-url').value=data.url;sourceUrl=data.url;}
  if(data.text){status('Page Safari reçue. Extraction des informations…');const response=await call('/api/capture',{title:data.title||'',text:data.text.slice(0,30000),ld:(data.ld||[]).slice(0,4),url:data.url||''});
    // Données structurées via navigateur : seules les valeurs extraites déjà détectées seront conservées.
    applyExtract(response);
  }else if(data.fields)applyExtract({fields:data.fields,evidence:data.evidence||{},source_url:data.url||'',method:'Safari'});
 }catch(e){status('Import du raccourci Safari incomplet : '+e.message,true);}}
fields();drawHistory();render();applyHash();
