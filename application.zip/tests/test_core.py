from finance import monthly_payment, calc
from extract import parse_text, parse_html, valid_public_url
import pytest


def sample():
    return dict(price=180_000,rent_monthly=1150,down_payment=10_000,notary_pct=8,
                works=0,furniture=3000,bank_fees=2500,years=25,interest_pct=3.4,
                insurance_pct=.2,copro_nonrecoverable=1200,property_tax=950,pno=120,
                accounting=0,cfe=0,other_charges=0,vacancy_pct=4,management_pct=0,maintenance_pct=5)


def test_credit_zero_interest():
    assert monthly_payment(120_000, 0, 10)==1000


def test_financial_consistency():
    v=sample()
    r=calc(v)
    assert r['total_cost']==199900
    assert r['loan']==189900
    assert r['monthly_debt']==pytest.approx(972.18, abs=.02)
    assert r['cashflow_monthly']==pytest.approx(-112.55,abs=.02)
    assert r['gross_yield_pct']==6.9
    assert r['max_buy_price']<v['price']
    assert r['rent_break_even']>v['rent_monthly']
    assert r['scenarios']['Loyer −10 %']['cashflow_monthly']<r['cashflow_monthly']
    assert r['scenarios']['Taux +1 point']['cashflow_monthly']<r['cashflow_monthly']


def test_no_rent_no_fake_cf():
    r=calc({**sample(),'rent_monthly':None})
    assert r['cashflow_monthly'] is None
    assert r['gross_yield_pct'] is None


def test_text_fr():
    r=parse_text('Appartement 2 pièces de 38 m² à Romainville (93230). Prix : 180 000 €. Charges : 150 € / mois. Taxe foncière : 980 €. DPE : D',title='Appartement Romainville (93230)')
    assert r['fields']['price']==180000
    assert r['fields']['surface']==38
    assert r['fields']['city']=='Romainville'
    assert r['fields']['rooms']==2
    assert r['fields']['dpe']=='D'
    assert r['fields']['copro_total']==1800
    assert r['fields']['property_tax']==980
    assert 'rent_monthly' not in r['fields']


def test_html_ldjson():
    html='''<html><head><title>Appartement</title><script type="application/ld+json">{"@type":"Product","offers":{"price":"187000"},"floorSize":{"value":38},"address":{"addressLocality":"Montreuil"}}</script></head><body>2 pièces. DPE : C</body></html>'''
    r=parse_html(html)
    assert r['fields']['price']==187000
    assert r['fields']['surface']==38
    assert r['fields']['city']=='Montreuil'

@pytest.mark.parametrize('url',['http://localhost/x','http://127.0.0.1/','http://10.0.1.1/', 'file:///etc/passwd','https://localhost.test/','http://example.com:1234'])
def test_reject_ssrf(url):
    with pytest.raises(ValueError): valid_public_url(url,resolve_dns=False)


def test_accept_regular_url():
    url='https://www.pap.fr/annonces/appartement-123'
    assert valid_public_url(url,resolve_dns=False)==url


def test_safari_capture_structured_fields():
    from extract import parse_capture
    c={'url':'https://exemple.fr/annonce','title':'Joli T2 Montreuil',
       'text':'Appartement 2 pièces. DPE D.',
       'ld':[{'@type':'Product','offers':{'price':'187000'},'floorSize':{'value':38},'address':{'addressLocality':'Montreuil'}}]}
    r=parse_capture(c)
    assert r['fields']['price']==187000
    assert r['fields']['surface']==38
    assert r['fields']['city']=='Montreuil'


def test_copro_quarterly_not_monthly():
    r=parse_text('Prix : 185 000 € — surface : 37 m² — charges : 400 € / trimestre')
    assert r['fields']['copro_total']==1600


def test_protected_listing_fallback(monkeypatch):
    import extract
    monkeypatch.setattr(extract,'valid_public_url',lambda url,**kw:url)
    def blocked(url):raise PermissionError('HTTP 403')
    monkeypatch.setattr(extract,'fetch_direct',blocked)
    monkeypatch.delenv('USE_JINA',raising=False)
    r=extract.import_url('https://example.com/annonce')
    assert r['blocked'] is True
    assert 'Safari' in r['warnings'][-1]
