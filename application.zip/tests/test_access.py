import pytest
from fastapi import HTTPException
from starlette.requests import Request
from app import require_access

def _request(key=''):
    headers=[(b'x-access-key',key.encode())] if key else []
    return Request({'type':'http','method':'POST','headers':headers,'path':'/api/import','query_string':b''})

def test_no_access_key_during_local_development(monkeypatch):
    monkeypatch.delenv('APP_ACCESS_KEY',raising=False)
    require_access(_request())

def test_authentication_enforced(monkeypatch):
    monkeypatch.setenv('APP_ACCESS_KEY','strong-test-key')
    with pytest.raises(HTTPException) as e:require_access(_request())
    assert e.value.status_code==401
    with pytest.raises(HTTPException):require_access(_request('incorrect'))
    require_access(_request('strong-test-key'))
